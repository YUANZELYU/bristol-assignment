//
// Included Files
//
#include "driverlib.h"
#include "device.h"

long long timer0;

// Globals
uint16_t cpuTimer0IntCount;
uint16_t cpuTimer1IntCount;
uint32_t timer0StartTime, timer0EndTime, timer1StartTime, timer1EndTime;
uint32_t timer0ExecutionTime, timer1ExecutionTime;

// Function Prototypes
__interrupt void cpuTimer0ISR(void);
__interrupt void cpuTimer1ISR(void);
void initCPUTimers(void);
void configCPUTimer(uint32_t, float, float);

//
// Main
//
void main(void)
{
    // Initializes device clock and peripherals
    Device_init();

    // Initializes PIE and clears PIE registers. Disables CPU interrupts.
    Interrupt_initModule();

    // Initializes the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    Interrupt_initVectorTable();

    // Register ISRs for each CPU Timer interrupt
    Interrupt_register(INT_TIMER0, &cpuTimer0ISR);
    Interrupt_register(INT_TIMER1, &cpuTimer1ISR);

    // Initialize CPU Timers (Timer 0, Timer 1, and Timer 2)
    initCPUTimers();

    // Configure CPU-Timer 0 and 1
    configCPUTimer(CPUTIMER0_BASE, DEVICE_SYSCLK_FREQ, 500000); // 0.5 second period
    configCPUTimer(CPUTIMER1_BASE, DEVICE_SYSCLK_FREQ, 2000000); // 2 second period
    configCPUTimer(CPUTIMER2_BASE, DEVICE_SYSCLK_FREQ, 1000000); // Free-running timer (1 MHz)

    // Enable interrupts for CPU Timers
    CPUTimer_enableInterrupt(CPUTIMER0_BASE);
    CPUTimer_enableInterrupt(CPUTIMER1_BASE);
    Interrupt_enable(INT_TIMER0); // This also enables interrupt 1.7 (Timer0)
    Interrupt_enable(INT_TIMER1);

    // Start CPU Timers
    CPUTimer_startTimer(CPUTIMER0_BASE);
    CPUTimer_startTimer(CPUTIMER1_BASE);
    CPUTimer_startTimer(CPUTIMER2_BASE);  // Start free-running Timer 2 for time measurement

    // Enable Global Interrupt (INTM) and real-time interrupt (DBGM)
    EINT;
    ERTM;

    // IDLE loop
    while(1)
    {
        // Optionally perform some actions based on timer interrupts
    }
}

//
// initCPUTimers - This function initializes all CPU timers
//
void initCPUTimers(void)
{
    // Initialize Timer 0 and Timer 1 periods to maximum
    CPUTimer_setPeriod(CPUTIMER0_BASE, 0xFFFFFFFF);
    CPUTimer_setPeriod(CPUTIMER1_BASE, 0xFFFFFFFF);

    // Set Timer 2 for free-running mode (used for time measurements)
    CPUTimer_setPeriod(CPUTIMER2_BASE, 0xFFFFFFFF);

    // Initialize pre-scale counters to divide by 1 (SYSCLKOUT)
    CPUTimer_setPreScaler(CPUTIMER0_BASE, 0);
    CPUTimer_setPreScaler(CPUTIMER1_BASE, 0);
    CPUTimer_setPreScaler(CPUTIMER2_BASE, 0);

    // Make sure timers are stopped
    CPUTimer_stopTimer(CPUTIMER0_BASE);
    CPUTimer_stopTimer(CPUTIMER1_BASE);
    CPUTimer_stopTimer(CPUTIMER2_BASE);

    // Reload all counter registers with period values
    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
    CPUTimer_reloadTimerCounter(CPUTIMER1_BASE);
    CPUTimer_reloadTimerCounter(CPUTIMER2_BASE);

    // Reset interrupt counters
    cpuTimer0IntCount = 0;
    cpuTimer1IntCount = 0;
}

//
// configCPUTimer - This function initializes the selected timer to the
// period specified by the "freq" and "period" parameters. The "freq" is
// entered as Hz and the period in uSeconds.
//
void configCPUTimer(uint32_t cpuTimer, float freq, float period)
{
    uint32_t temp = (uint32_t)(freq / 1000000 * period);

    // Initialize timer period
    CPUTimer_setPeriod(cpuTimer, temp);

    // Set pre-scale counter to divide by 1 (SYSCLKOUT)
    CPUTimer_setPreScaler(cpuTimer, 0);

    // Initializes timer control register. The timer is stopped, reloaded,
    // free run disabled, and interrupt enabled.
    CPUTimer_stopTimer(cpuTimer);
    CPUTimer_reloadTimerCounter(cpuTimer);
    CPUTimer_setEmulationMode(cpuTimer, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(cpuTimer);

    // Reset interrupt counter for the specified timer
    if (cpuTimer == CPUTIMER0_BASE)
    {
        cpuTimer0IntCount = 0;
    }
    else if (cpuTimer == CPUTIMER1_BASE)
    {
        cpuTimer1IntCount = 0;
    }
}

//
// cpuTimer0ISR - ISR for CPU Timer 0 (with execution time measurement)
//
__interrupt void cpuTimer0ISR(void)
{
    // Start measuring time at the beginning of the ISR
    timer0StartTime = CPUTimer_getTimerCount(CPUTIMER2_BASE);

    // Simulate a delay in the ISR
    volatile int i;
    for (i = 0; i < 100; i++); // Simple busy-wait delay

    // Increment the Timer 0 interrupt counter
    cpuTimer0IntCount++;

    // End time measurement
    timer0EndTime = CPUTimer_getTimerCount(CPUTIMER2_BASE);
    timer0ExecutionTime = timer0StartTime - timer0EndTime; // Calculate time spent in ISR

    // Acknowledge the interrupt to receive more interrupts from Group 1
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

//
// cpuTimer1ISR - ISR for CPU Timer 1 (with execution time measurement)
//
__interrupt void cpuTimer1ISR(void)
{
    // Start measuring time at the beginning of the ISR
    timer1StartTime = CPUTimer_getTimerCount(CPUTIMER2_BASE);

    // Increment the Timer 1 interrupt counter
    cpuTimer1IntCount++;

    // End time measurement
    timer1EndTime = CPUTimer_getTimerCount(CPUTIMER2_BASE);
    timer1ExecutionTime = timer1StartTime - timer1EndTime; // Calculate time spent in ISR

    // Acknowledge the interrupt to receive more interrupts from Group 1
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

//
// End of File
//
